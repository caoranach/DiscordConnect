# 1.0.3
Added a basic feature to allow splitting rolls and chat messages into two different discord channels, using multiple webhooks.

# 1.0.2
Added a feature to allow users to block private messages/rolls from being copied to discord.

# 1.0.1
Added a feature to allow a "main GM" to be specified, as a simple way of preventing unwanted duplication of messages due to multiple GMs in a session.

# 1.0.0
Initial release
