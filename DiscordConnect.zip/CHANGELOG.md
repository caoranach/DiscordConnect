# 1.0.1
Added a feature to allow a "main GM" to be specified, as a simple way of preventing unwanted duplication of messages due to multiple GMs in a session.

# 1.0.0
Initial release